#include "splashkit.h"
#include <string>
using namespace std;

struct Knight_data
{
    string name;
    int age;
};
string read_string(string prompt)
{
    string result;
    write(prompt);
    result =  read_line();
    return result;
}
int read_integer(string prompt)
{
  string result;
  write(prompt);
  result = read_line();
  return convert_to_integer(result);
}
Knight_data read_knight()
{
    
    Knight_data result;
    result.name = read_string("Enter Name :");
    result.age = read_integer("Enter Age:");
    return result;

 
}
void write_knight (const Knight_data &knight)
{
     write_line("Hello "+knight.name+" Age "+to_string(knight.age));
}
void update_knight(Knight_data &knight)
{
    int option;
    do
    {
        write_line();
        write_line("==Update Knight ==");
        write_knight(knight);
        write_line();
        write_line("1: Upade name");
        write_line("2 : Update age");
        write_line("3.Finish Update");
       // option = read_integer("Select option: ");
        
        switch(option)
        {
            case 1:
                knight.name = read_string("Enter New name: ");
                break;
            case 2:
                knight.age = read_integer("Enter new Age: ");
                break;
            case 3:
                break;
            default:
                write_line("Please select a valid option :");
        }
    } while ( option !=3 );
} 
int main()
{
    Knight_data my_knight;
    my_knight = read_knight();
    write_knight(my_knight);
    update_knight(my_knight);
    write_line("After update backe in main");
    write_knight(my_knight);
   
    return 0;
}